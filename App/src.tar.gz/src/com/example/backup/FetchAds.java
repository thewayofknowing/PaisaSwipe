package com.example.backup;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Window;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


public class FetchAds extends Activity {
	
	int s_totalSize;
	List<String> s_adURL_List;
	String s_imageURL;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		Bundle extras = getIntent().getExtras();
		s_totalSize = 0;
		try {
			JSONArray adListArray = new JSONArray(extras.getString("json"));
			for(int i=0; i<adListArray.length(); i++) {
				JSONObject object = adListArray.getJSONObject(i);
				s_totalSize += Integer.parseInt(object.getString("image_size"));
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	public class DownloadImages extends AsyncTask<String, String, String>{

		public static final int CONNECTION_TIMEOUT = 10000;
		Dialog s_dialog;
		ProgressBar s_progressBar;
		TextView s_progressText;
		Bitmap s_bitmap;
		int lenghtOfFile;
		int counter = 0;
		Context context;
		int sumSize;
		
		public DownloadImages(Context context) {
			this.context = context;
			s_dialog = new Dialog(context);
		}
		
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			s_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
			s_dialog.setContentView(R.layout.download_dialog);
			s_dialog.setCancelable(false);
			s_progressBar = (ProgressBar) s_dialog.findViewById(R.id.progressBar1);
			s_progressBar.setMax(s_totalSize);
			s_progressBar.setProgress(0);
			s_progressText = (TextView) s_dialog.findViewById(R.id.textView1);
			
			s_dialog.show();
		}
		
		@Override
		protected String doInBackground(String... arg0) {
			s_bitmap = getImageBitmap(null);
			return null;
		}
		
		@Override
		protected void onProgressUpdate(String... values) {
			super.onProgressUpdate(values);
			s_progressBar.setProgress(Integer.parseInt(values[0]));
			s_progressText.setText(Integer.parseInt(values[0])/1024 + "Kb Downloaded");
		}
		
		public synchronized Bitmap getImageBitmap(URL url) {
			int count;
			try {
				url = new URL(s_imageURL);
				URLConnection conn = url.openConnection();
				conn.setConnectTimeout(CONNECTION_TIMEOUT);
				conn.connect();
			    lenghtOfFile = conn.getContentLength();
			    InputStream input = new BufferedInputStream(url.openStream());
			    byte data[] = new byte[1024];
			    byte sumData[] = new byte[1000000];
			    long total = 0;
			    sumSize = 0;

			        while ((count = input.read(data)) != -1) {
			            total += count;
			            publishProgress(""+ sumSize);
			            for(int i=0;i<count;i++) {
			            	sumData[sumSize++] = data[i];
			            }
			        }
			    
		        ByteArrayInputStream imageStream = new ByteArrayInputStream(sumData);
	            return BitmapFactory.decodeStream(imageStream);
			} catch (IOException e) {
				return null;
			}
		}
		
		protected void onPostExecute(String result) {
			s_dialog.dismiss();
			Toast.makeText(context, sumSize + "", Toast.LENGTH_LONG).show();
		};

	}
	
}
